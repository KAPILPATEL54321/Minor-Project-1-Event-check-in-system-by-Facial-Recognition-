import os
from tkinter import*
from tkinter import filedialog,messagebox
import sqlite3
class GuestFrame:

    def __init__(self,root):
        self.root=root
        self.root.title("Unknown Guest")
        self.root.geometry("500x500+100+100")

#==========================All Variables=======================================
        self.Name_var = StringVar()
        self.Email_var = StringVar()
        self.Contact_var = StringVar()
        self.Photo_var=PhotoImage()
        with open("Temp1/Unknown Face.jpg", 'rb') as f:
            self.Photo_var= f.read()
#================================================================================================

        Manage_Frame = Frame(self.root, bd=4, relief=RIDGE, bg="crimson")
        Manage_Frame.place(x=10, y=10, width=450, height=450)

        m_title = Label(Manage_Frame, text="Unknown Guest", bg="crimson", fg="white",
                        font=("times new roman", 20, "bold"))
        m_title.grid(row=0, columnspan=2, pady=20)


        lbl_name = Label(Manage_Frame, text="Name", bg="crimson", fg="white", font=("times new roman", 20, "bold"))
        lbl_name.grid(row=1, column=0, pady=2, padx=20, sticky="w")

        txt_name = Entry(Manage_Frame, textvariable=self.Name_var, font=("times new roman", 15, "bold"), bd=5,
                         relief=GROOVE)
        txt_name.grid(row=1, column=1, pady=2, padx=20, sticky="w")

        lbl_Email = Label(Manage_Frame, text="Email", bg="crimson", fg="white", font=("times new roman", 20, "bold"))
        lbl_Email.grid(row=2, column=0, pady=2, padx=20, sticky="w")

        txt_Email = Entry(Manage_Frame, textvariable=self.Email_var, font=("times new roman", 15, "bold"), bd=5,
                          relief=GROOVE)
        txt_Email.grid(row=2, column=1, pady=2, padx=20, sticky="w")
        lbl_Contact = Label(Manage_Frame, text="Contact", bg="crimson", fg="white",
                            font=("times new roman", 20, "bold"))
        lbl_Contact.grid(row=3, column=0, pady=2, padx=20, sticky="w")

        txt_Contact = Entry(Manage_Frame, textvariable=self.Contact_var, font=("times new roman", 15, "bold"), bd=5,
                            relief=GROOVE)
        txt_Contact.grid(row=3, column=1, pady=2, padx=20, sticky="w")

        Addbtn = Button(Manage_Frame, text="Add", width=10, command=self.add_Guests).grid(row=4, column=1, padx=10,
                                                                                 pady=10)

    def add_Guests(self):
        if self.Name_var.get() == "" or self.Email_var.get() == "" or self.Contact_var.get() == "" :
            messagebox.showerror("Error", "All Fields are required!!!!")
        else:
            mydb = sqlite3.connect("Event.db")
            mycursor = mydb.cursor()
            print(self.Name_var.get(), self.Email_var.get(), self.Contact_var.get(),self.Photo_var)
            mycursor.execute(""" INSERT INTO unknowns (Name,Email,Contact,Photo) VALUES (?,?,?,?)""",
                             (self.Name_var.get(), self.Email_var.get(), self.Contact_var.get(), self.Photo_var))
            mydb.commit()
            mydb.close()
            messagebox.showinfo("Success", "Record has been Inserted")



root1=Tk()
obj=GuestFrame(root1)
root1.mainloop()